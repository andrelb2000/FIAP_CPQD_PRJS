Example 1
=========

Close to the simplest possible example of Unity, using only basic features.

Build and run with Make
---
Just run `make`.

Build and run with Meson
---
Run `meson setup build` to create the build directory, and then `meson test -C build` to build and run the tests.
